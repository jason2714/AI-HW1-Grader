# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())


    """
    "*** YOUR CODE HERE ***"
    pathToGoal = []                             # list to store path to reach goal
    MemoryStackType = util.Stack()              # to do depth first search from one node to another using last-in-first-out  
    visitedNode=[]                              # to store list of visited node
    startPosition = problem.getStartState()     # the starting position of the picman on the maze
    isGoal= problem.isGoalState(startPosition)  # checking whether the start position is the goal
    #print startPosition
    currentPosition = startPosition             # for the first loop the current node is the start position which is the root node of the search tree 
    
    while isGoal == False:                      # the search will be recursive from one node to another until the goal node is found, while the current node is not goal 
        possibleMoves = problem.getSuccessors(currentPosition)  # look for its child node
        visitedNode.append(currentPosition)     # add current node to visited node list
        for move  in possibleMoves:             # for all the neighbour node
            if move[0] not in visitedNode:      # if each neighbour node has not been visited add the node to the memory stack for search
                tempPath=pathToGoal+[move[1]]   # the list of direction to reach this child node 
                #print "TempPath",tempPath
                MemoryStackType.push((move[0],tempPath)) # put this child node into the stack in this dictionary [position(x,y), list of accumulated directions from start to this position], this allow us to link the node and the path respectively
        
        # to move down to the child node (depth search)   
        if MemoryStackType.isEmpty() ==False:   #if the stack is not empty,
            currentPosition,pathToGoal = MemoryStackType.pop()  # pop the top element on the stack, update current node and path for next node
            isGoal = problem.isGoalState(currentPosition)       # check if this next node is goal, if not, move to this node and do the recursive search from this child node again
            if isGoal == True:                                  # if it is goal, return the path to reach this node     
                return pathToGoal                               # the path to goal is returned, search ended 
            #print currentPosition
            #print pathToGoal       
    #return None                                                 # if there is no goal the loop will never end     
    #util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    pathToGoal = []                             # list to store path to reach goal
    MemoryQueueType = util.Queue()              # to do breadth first search from one node to another the neighbor nodes need to be in queue format as first-in-first-out
    visitedNode=[]                              # to store list of visited node
    startPosition = problem.getStartState()     # the starting position of the picman on the maze
    isGoal= problem.isGoalState(startPosition)  # checking whether the start position is the goal
    currentPosition = startPosition             # the current node is the start position which is the root node of the search tree for the first time of the loop
    while isGoal == False:                      # while the current node is not a goal     
        possibleMoves = problem.getSuccessors(currentPosition)  # look for its child node, the possible moves from current position
        visitedNode.append(currentPosition)     # add current node to visited node list
        for move  in possibleMoves:             # for all the neighbouring node, if it is not visited add the node to the queue for visit  
            if move[0] not in visitedNode:
                tempPath=pathToGoal+[move[1]]   #adding a directon to get to this child node from current position (accummulation of direction from starting position)
                #print "TempPath",tempPath
                MemoryQueueType.push((move[0],tempPath)) # put this child node into the queue in  [position(x,y), list of accumulated directions from start to this position] format, this allow us to link the node and the path respectively

        # to visit all the child node in the next level (breath search) to check if there is goal node, if not, then go down one level to the child node and do the search again on next level
        while MemoryQueueType.isEmpty() ==False and currentPosition in visitedNode: # while the current node is visited and there is child nodes in queue 
            currentPosition,pathToGoal = MemoryQueueType.pop()      # pop the first node in queue   
            isGoal = problem.isGoalState(currentPosition)           # check if it is goal       
            if isGoal == True:                                      # if it is goal, return the path to this node for starting point
                return pathToGoal   
    #util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    # For this search it is similar to BFS but for the next node is least toal cost node is selected insead of being random
    # to accomplish this the priority queue which is order according to the priority is used for choosing the least total cost node first
    pathCost = 0                            # total path cost from starting position
    pathToGoal = []                         # list to store path to reach goal
    MemoryPriorityQueueType = util.PriorityQueue() # for uniform cost search, ordering the neighboring nodes with lowest total cost to the front of the queue
    visitedNode=[]                              # to store list of visited node
    startPosition = problem.getStartState()     # the starting position of the picman on the maze
    isGoal= problem.isGoalState(startPosition)  # checking whether the start position is the goal
    currentPosition = startPosition             # the current node is the start position which is the root node of the search tree for the first time of the loop
    while isGoal == False:                      # while the current node is not a goal     
        possibleMoves = problem.getSuccessors(currentPosition)  # look for its child node, the possible moves from current position
        visitedNode.append(currentPosition)     # add current node to visited node list
        for move  in possibleMoves:             # for all the neighbouring node, if it is not visited add the node to the queue for visit  
            if move[0] not in visitedNode:
                tempPath=pathToGoal+[move[1]]   #adding a directon to get to this child node from current position (accummulation of direction from starting position)
                #print "TempPath",tempPath
                priority= pathCost + move[2]    #adding the total cost to this child node from the current position (accummulation of cost from starting position)
                MemoryPriorityQueueType.push((move[0],tempPath,priority),priority) # put this child node into the queue in the format below: 
                #[position(x,y), list of accumulated directions from start to this position, total cost], this allow us to link the node, the path and cost from starting position respectively
        
        # to go to the next lowest total cost node and search for goal node 
        while MemoryPriorityQueueType.isEmpty() == False and currentPosition in visitedNode: # while the priority queue is not empty and the current node has been visited
            currentPosition,pathToGoal,pathCost = MemoryPriorityQueueType.pop() # pop the lowest priority node and assign as current node and respective information for its path and total cost
            isGoal = problem.isGoalState(currentPosition)   # check if this node goal, if not repeat the search again from this node 
            if isGoal == True:                              # if it is a goal node, return the path from the starting point to the goal
                return pathToGoal
    #util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    # For this search it is similar to uniform cost search but as define above it search for the node that have the lowest combination of cost and heuristic first.
    pathToGoal = []             # list to store path to reach goal
    MemoryPriorityQueueType = util.PriorityQueue()  # for ordering the neighboring nodes with lowest combine cost and heuristic to be at the front of the queue
    visitedNode=[]               # to store list of visited node
    pathCost = 0                 # total path cost from starting position
    startPosition = problem.getStartState()     # the starting position of the picman on the maze
    isGoal= problem.isGoalState(startPosition)  # checking whether the start position is the goal
    currentPosition = startPosition             # the current node is the start position which is the root node of the search tree for the first time of the loop
    while isGoal == False:                      # while the current node is not a goal
        possibleMoves = problem.getSuccessors(currentPosition)  # look for its child node, the possible moves from current position
        visitedNode.append(currentPosition)     # add current node to visited node list
        for move  in possibleMoves:             # for all the neighbouring node, if it is not visited add the node to the queue for visit  
            if move[0] not in visitedNode:
                tempPath=pathToGoal+[move[1]]   #adding a directon to get to this child node from current position (accummulation of direction from starting position)
                #print "TempPath",tempPath
                cost= pathCost + move[2]                     # the cost of the path from the starting point
                priority = cost + heuristic(move[0],problem) # the queue is order according to the lowest combined cost and heuristic instead
                MemoryPriorityQueueType.push((move[0],tempPath,cost),priority) # this child node is added to the queue is the format below:
                #[position(x,y), list of accumulated directions from start to this position, total cost], this allow us to link the node, the path and cost from starting position respectively
        
        # to go to the next lowest total cost node and search for goal node 
        while MemoryPriorityQueueType.isEmpty() ==False and currentPosition in visitedNode: # while the priority queue is not empty and the current node has been visited
            currentPosition,pathToGoal,pathCost = MemoryPriorityQueueType.pop() # pop the lowest priority node and assign as current node and respective information for its path and total cost
            isGoal = problem.isGoalState(currentPosition) # check if this node goal, if not repeat the search again from this node 
            if isGoal == True:                            # if it is a goal node, return the path from the starting point to the goal
                return pathToGoal
    
    #util.raiseNotDefined()

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
