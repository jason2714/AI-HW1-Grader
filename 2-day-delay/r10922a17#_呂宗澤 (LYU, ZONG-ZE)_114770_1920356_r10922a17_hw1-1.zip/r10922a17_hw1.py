# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    from util import Stack
    waiting_state = Stack()
    marked = []
    edgeTo = {}

    # As the begining,s be the starting state, while s would be current state during processing.
    s = problem.getStartState()
    while (not problem.isGoalState(s)):
        if s not in marked:
            marked.append(s)
            for successor , action, _ in problem.getSuccessors(s):
                if successor not in marked:
                    waiting_state.push(successor)
                    edgeTo[successor] = (s, action)
        s = waiting_state.pop()
    # s should be goal state after <while> loop
    return pathTo(problem, edgeTo, goal= s)
    # util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    # Just Copy-Paste from dfs
    # Instead Queue from Stack
    from util import Queue
    waiting_state = Queue()
    marked = []
    edgeTo = {}

    # As the begining,s be the starting state, while s would be current state during processing.
    s = problem.getStartState()
    while (not problem.isGoalState(s)):
        if s not in marked:
            marked.append(s)
            for successor , action, _ in problem.getSuccessors(s):
                if successor not in marked:
                    waiting_state.push(successor)
                    edgeTo[successor] = (s, action)
        s = waiting_state.pop()
    # s should be goal state after <while> loop
    return pathTo(problem, edgeTo, goal= s)

    util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    from util import PriorityQueue
    waiting_state = PriorityQueue()
    marked = []
    edgeTo = {}
    distTo = {}
    # As the begining,s be the starting state, while s would be current state during processing.
    s = problem.getStartState()
    distTo[s] = 0
    while (not problem.isGoalState(s)):
        if s not in marked:
            marked.append(s)
            for successor , action, _ in problem.getSuccessors(s):
                temp_d = distTo[s] + problem.getCostOfActions([action])
                if successor not in marked:
                    if successor in distTo.keys():
                        if temp_d < distTo[successor]:
                            distTo[successor] = temp_d
                    else:
                        distTo[successor] = temp_d
                    waiting_state.update(successor, distTo[successor])
                    edgeTo[successor] = (s, action)
        s = waiting_state.pop()
    # s should be goal state after <while> loop
    return pathTo(problem, edgeTo, goal= s)


    #util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    from util import PriorityQueue
    waiting_state = PriorityQueue()
    marked = []
    edgeTo = {}
    distTo = {}
    # As the begining,s be the starting state, while s would be current state during processing.
    s = problem.getStartState()
    distTo[s] = 0
    while (not problem.isGoalState(s)):
        if s not in marked:
            marked.append(s)
            for successor , action, cost in problem.getSuccessors(s):
                temp_d = distTo[s] + problem.getCostOfActions([action])
                if successor not in marked:
                    if successor in distTo.keys():
                        if temp_d < distTo[successor]:
                            distTo[successor] = temp_d
                    else:
                        distTo[successor] = temp_d
                    edgeTo[successor] = (s, action)
                    waiting_state.update(successor, cost+distTo[successor])
                # elif distTo[successor] < temp_d:
                #     distTo[successor] = temp_d
                #     edgeTo[successor] = (s, action)
                #     waiting_state.update(successor, temp_d)
        s = waiting_state.pop()
    # s should be goal state after <while> loop
    return pathTo(problem, edgeTo, goal= s)

    # util.raiseNotDefined()

def pathTo(problem, edgeTo, goal):
    from util import Stack
    reverse_path = Stack()
    v = goal
    while v != problem.getStartState():
        successor, action = edgeTo[v]
        reverse_path.push(action)
        v = successor

    path = []
    while not reverse_path.isEmpty():
        path.append(reverse_path.pop())
    return path

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
